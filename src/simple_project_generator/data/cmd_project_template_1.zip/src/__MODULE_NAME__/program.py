import os
import sys
import signal
import argparse
import subprocess
import webbrowser

import {MODULE_NAME}.about as about
import {MODULE_NAME}.modules.configure as configure
from {MODULE_NAME}.modules.resources import resource_path
from {MODULE_NAME}.modules.wabout    import show_about
from {MODULE_NAME}.desktop import (
    create_desktop_file,
    create_desktop_directory,
    create_desktop_menu
)

# ---------- Path to config file ----------
CONFIG_PATH = os.path.join(
    os.path.expanduser("~"),
    ".config",
    about.__package__,
    "config.json"
)

DEFAULT_CONTENT = {
    "cli_configure_description": "Open the configuration file",
    "cli_about_description": "Show program information",
    "cli_coffee_description": "Buy me a coffee (TrucomanX)",
    "cli_output_dir_description": "Output directory where the project snapshot will be generated"
}

configure.verify_default_config(CONFIG_PATH, default_content=DEFAULT_CONTENT)
CONFIG = configure.load_config(CONFIG_PATH)
# ------------------------------------------


# ----------------------------------------------------------
# Utility Functions
# ----------------------------------------------------------

def open_file_in_text_editor(filepath):
    if os.name == "nt":
        os.startfile(filepath)
    elif os.name == "posix":
        subprocess.run(["xdg-open", filepath])


def open_coffee():
    webbrowser.open("https://ko-fi.com/trucomanx")


def run_main_logic(output_dir):
    """
    Dummy main logic function.
    Here is where your real program logic will go.
    """
    output_dir = os.path.abspath(os.path.expanduser(output_dir))
    print(f"Running main program...")
    print(f"Output directory: {output_dir}")


# ----------------------------------------------------------
# Main CLI
# ----------------------------------------------------------

def main():
    signal.signal(signal.SIGINT, signal.SIG_DFL)

    parser = argparse.ArgumentParser(
        prog=about.__program_name__,
        description=about.__description__
    )

    parser.add_argument(
        "--configure",
        action="store_true",
        help=CONFIG["cli_configure_description"]
    )

    parser.add_argument(
        "--about",
        action="store_true",
        help=CONFIG["cli_about_description"]
    )

    parser.add_argument(
        "--coffee",
        action="store_true",
        help=CONFIG["cli_coffee_description"]
    )

    parser.add_argument(
        "--autostart",
        action="store_true",
        help="Install application in autostart"
    )

    parser.add_argument(
        "--applications",
        action="store_true",
        help="Install application in applications menu"
    )

    parser.add_argument(
        "--output-dir",
        type=str,
        help=CONFIG["cli_output_dir_description"]
    )

    args = parser.parse_args()

    # ---------------- Actions ----------------

    if args.configure:
        open_file_in_text_editor(CONFIG_PATH)
        return

    if args.about:
        show_about()
        return

    if args.coffee:
        open_coffee()
        return

    if args.autostart:
        create_desktop_directory(overwrite=True)
        create_desktop_menu(overwrite=True)
        create_desktop_file(
            os.path.join("~", ".config", "autostart"),
            overwrite=True,
            program_name=about.__program_name__
        )
        print("Autostart entry created.")
        return

    if args.applications:
        create_desktop_directory(overwrite=True)
        create_desktop_menu(overwrite=True)
        create_desktop_file(
            os.path.join("~", ".local", "share", "applications"),
            overwrite=True,
            program_name=about.__program_name__
        )
        print("Application menu entry created.")
        return

    # -------------------------------------------------
    # Main Program Logic
    # -------------------------------------------------

    if args.output_dir:
        run_main_logic(args.output_dir)
        return

    # If nothing provided
    parser.print_help()


if __name__ == "__main__":
    main()

