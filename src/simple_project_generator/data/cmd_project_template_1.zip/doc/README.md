# Documentation

* [Install the program](INSTALL.md)
* [Configure the program](CONFIGURE.md)
* [Upload to PYPI](UPLOAD.md)
* [Testing from source](TESTING.md)
