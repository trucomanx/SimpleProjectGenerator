# about.py

__version__ = "0.1.0"
__package__ = "{MODULE_NAME}"
__program_name__ = "{PROGRAM_NAME}"
__author__ = "{AUTHOR_NAME}"
__email__  = "{AUTHOR_EMAIL}"
__description__ = "{SUMMARY}"
__url_source__  = "{REPOSITORY_PAGE}/{REPOSITORY_NAME}"
__url_doc__  = "{REPOSITORY_PAGE}/{REPOSITORY_NAME}/tree/main/doc"
__url_funding__ = "{FUNDING_PAGE}"
__url_bugs__    = "{REPOSITORY_PAGE}/{REPOSITORY_NAME}/issues"
