# {PROGRAM_NAME}

{SUMMARY}

## Upload to PYPI

```bash
pip install --upgrade pkginfo twine packaging

cd src
python -m build
twine upload dist/*
```
