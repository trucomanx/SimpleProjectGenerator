# {PROGRAM_NAME}

{SUMMARY}

# Configure

Go to `Configure` to open the `~/config/{MODULE_NAME}/config.json` file. 

